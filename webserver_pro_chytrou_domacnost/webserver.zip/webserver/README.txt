Server používa knižnicu suntime (https://pypi.org/project/suntime/) na čas východu/západu slnka podľa súradníc

Prihlasovacie meno a heslo sú rovnaké:
- karsob, karsob
- karlos, karlos
- julia, julia
- karlik, karlik
